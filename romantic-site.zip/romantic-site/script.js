// =============================================
//   ROMANTIC WEBSITE — script.js
//
//   🔧 CHANGE GUIDE:
//   - Start date: Find "START_DATE" and update it
//   - Funny messages: Edit "funnyMessages" array
//   - Heart emojis: Edit "heartEmojis" array
//   - Confetti colors: Edit "confettiColors" array
// =============================================

// ========== PAGE NAVIGATION ==========
function goTo(pageId) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(p => {
    p.classList.remove('active');
  });

  // Show target page
  const target = document.getElementById(pageId);
  if (target) {
    target.classList.add('active');
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
    // Re-trigger fade animation
    const content = target.querySelector('.fade-in');
    if (content) {
      content.style.animation = 'none';
      content.offsetHeight; // reflow
      content.style.animation = '';
    }
  }

  // Start music on first interaction
  tryPlayMusic();
}

// ========== MUSIC ==========
let musicPlaying = false;
const music = document.getElementById('bgMusic');
const musicBtn = document.getElementById('musicBtn');

function tryPlayMusic() {
  if (!musicPlaying && music) {
    music.volume = 0.35; // 🔧 CHANGE: Adjust volume (0.0 to 1.0)
    music.play()
      .then(() => {
        musicPlaying = true;
        musicBtn.classList.add('playing');
        musicBtn.textContent = '🎵';
      })
      .catch(() => {
        // Autoplay blocked — user needs to click
      });
  }
}

function toggleMusic() {
  if (!music) return;
  if (musicPlaying) {
    music.pause();
    musicPlaying = false;
    musicBtn.classList.remove('playing');
    musicBtn.textContent = '🔇';
  } else {
    music.volume = 0.35;
    music.play();
    musicPlaying = true;
    musicBtn.classList.add('playing');
    musicBtn.textContent = '🎵';
  }
}

// ========== NO BUTTON (Page 2) ==========
// 🔧 CHANGE: Edit funny messages
const funnyMessages = [
  "Nice try 😂",
  "Wrong answer bestie 💅",
  "The button said NO to you 😭",
  "It's giving... avoidance 🏃‍♂️",
  "Come on, you know the answer 🥺",
  "Don't lie to yourself 💀",
  "The button is scared of commitment 😂",
  "Okay but like... yes? 👀",
];

let funnyIndex = 0;
let noMoveCount = 0;

function moveNoBtn() {
  const btn = document.getElementById('noBtn');
  if (!btn) return;

  noMoveCount++;

  // After 5 attempts, show the YES button animation
  if (noMoveCount >= 5) {
    document.getElementById('funnyText').textContent = "Okay fine... YES it is! 💖";
    btn.style.opacity = '0.1';
    btn.style.pointerEvents = 'none';
    return;
  }

  const container = btn.parentElement;
  const rect = container.getBoundingClientRect();
  const btnRect = btn.getBoundingClientRect();

  const maxX = Math.min(rect.width - btnRect.width - 20, 300);
  const maxY = Math.min(rect.height - btnRect.height - 20, 100);

  const randomX = (Math.random() * maxX * 2 - maxX);
  const randomY = (Math.random() * maxY * 2 - maxY);

  btn.style.transform = `translate(${randomX}px, ${randomY}px)`;
  btn.style.transition = 'transform 0.2s ease';

  // Show funny message
  const msgEl = document.getElementById('funnyText');
  msgEl.textContent = funnyMessages[funnyIndex % funnyMessages.length];
  funnyIndex++;
}

// Same for page 6 NO button
let noMoveCount2 = 0;
function moveNoBtn2() {
  const btn = document.getElementById('noBtn2');
  if (!btn) return;

  noMoveCount2++;

  if (noMoveCount2 >= 5) {
    btn.style.opacity = '0.05';
    btn.style.pointerEvents = 'none';
    return;
  }

  const randomX = (Math.random() * 400 - 200);
  const randomY = (Math.random() * 200 - 100);
  btn.style.transform = `translate(${randomX}px, ${randomY}px)`;
  btn.style.transition = 'transform 0.2s ease';
}

// ========== CONFETTI ==========
// 🔧 CHANGE: Edit confetti colors
const confettiColors = ['#ff6b8a','#ffb6c1','#c084fc','#ffd4e0','#ff9fb8','#e879f9','#f472b6','#fbbf24','#ffffff'];

function showConfetti() {
  const overlay = document.getElementById('confettiOverlay');
  overlay.classList.remove('hidden');

  // Create confetti pieces
  for (let i = 0; i < 120; i++) {
    setTimeout(() => {
      const piece = document.createElement('div');
      piece.className = 'confetti-piece';

      // Random properties
      const color = confettiColors[Math.floor(Math.random() * confettiColors.length)];
      const size = Math.random() * 10 + 6;
      const left = Math.random() * 100;
      const delay = Math.random() * 1.5;
      const duration = Math.random() * 2 + 2;
      const shapes = ['2px', '50%', '0'];
      const shape = shapes[Math.floor(Math.random() * shapes.length)];

      piece.style.cssText = `
        background: ${color};
        width: ${size}px;
        height: ${size}px;
        left: ${left}%;
        top: -20px;
        border-radius: ${shape};
        animation: confetti-fall ${duration}s ${delay}s linear forwards;
      `;

      overlay.appendChild(piece);
    }, i * 20);
  }

  // Go to final page after confetti
  setTimeout(() => {
    overlay.classList.add('hidden');
    overlay.innerHTML = '';
    goTo('page9');
  }, 4000);
}

// ========== DAYS COUNTER ==========
// 🔧 CHANGE: Replace this date with your actual start date (YYYY, MM-1, DD)
// Note: Month is 0-indexed: Jan=0, Feb=1, Mar=2 ... Dec=11
const START_DATE = new Date(2024, 0, 1); // 🔧 = January 1, 2024

function updateDayCounter() {
  const el = document.getElementById('dayCounter');
  if (!el) return;

  const today = new Date();
  const diffMs = today - START_DATE;
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  // Animate count up
  let count = 0;
  const target = Math.max(0, diffDays);
  const step = Math.ceil(target / 60);

  const interval = setInterval(() => {
    count = Math.min(count + step, target);
    el.textContent = count.toLocaleString();
    if (count >= target) clearInterval(interval);
  }, 30);
}

// Run counter when page 9 becomes visible
const observer = new MutationObserver(() => {
  const page9 = document.getElementById('page9');
  if (page9 && page9.classList.contains('active')) {
    updateDayCounter();
  }
});
observer.observe(document.body, { subtree: true, attributes: true, attributeFilter: ['class'] });

// ========== FLOATING HEARTS ==========
// 🔧 CHANGE: Add or remove emojis from this list
const heartEmojis = ['💖','💕','💗','💓','💞','💘','🌸','✨','🌷','💝','🫶','💫'];

function createFloatingHeart() {
  const container = document.getElementById('heartsContainer');
  if (!container) return;

  const heart = document.createElement('div');
  heart.className = 'floating-heart';
  heart.textContent = heartEmojis[Math.floor(Math.random() * heartEmojis.length)];

  // Random position and size
  const left = Math.random() * 100;
  const size = Math.random() * 1 + 0.7;
  const duration = Math.random() * 8 + 8;
  const delay = Math.random() * 4;

  heart.style.cssText = `
    left: ${left}%;
    font-size: ${size}rem;
    animation-duration: ${duration}s;
    animation-delay: ${delay}s;
  `;

  container.appendChild(heart);

  // Remove after animation
  setTimeout(() => {
    heart.remove();
  }, (duration + delay) * 1000);
}

// Spawn hearts periodically
setInterval(createFloatingHeart, 1200);
// Create a few immediately
for (let i = 0; i < 6; i++) {
  setTimeout(createFloatingHeart, i * 400);
}

// ========== INIT ==========
// Show page 1 on load
document.addEventListener('DOMContentLoaded', () => {
  const page1 = document.getElementById('page1');
  if (page1) page1.classList.add('active');

  // Try music on user's first interaction with the page
  document.addEventListener('click', tryPlayMusic, { once: true });
  document.addEventListener('touchstart', tryPlayMusic, { once: true });
});
