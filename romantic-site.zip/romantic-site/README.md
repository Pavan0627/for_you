# 💖 Romantic Website — Full Setup Guide

## 📁 Folder Structure

```
romantic-site/
├── index.html       → All pages & structure
├── style.css        → All colors, fonts, layout
├── script.js        → All animations & logic
├── images/          → Put ALL your photos & music here
│   ├── music.mp3    ← 🎵 YOUR SONG (rename to music.mp3)
│   ├── photo1.jpg   ← YOUR PHOTOS
│   ├── photo2.jpg
│   ├── photo3.jpg
│   ├── photo4.jpg
│   ├── photo5.jpg
│   └── photo6.jpg
└── README.md        → This guide
```

---

## 🔧 WHAT TO CHANGE — QUICK GUIDE

### 👤 Her Name
**File:** `index.html`
Search for: `Aayushi`
Change to her actual name

---

### 📖 Page 2 — Question
**File:** `index.html`, Section `page2`
Change the h2 text: "Can I show you something special?"

---

### 🕐 Timeline Memories
**File:** `index.html`, Section `page3`
Each `.timeline-item` has:
- `timeline-date` → The label (e.g., "Day 1", "June 2023")
- `h3` → Memory title
- `p` → Memory description

Add more items by copy-pasting a `.timeline-item` block.

---

### 📸 Photos
**File:** `index.html`, Section `page4`

Step 1: Put your photos in `/images/` folder
Step 2: In each `.photo-card`, replace the placeholder div with:
```html
<img src="images/photo1.jpg" alt="Us">
```
Step 3: Change the `.photo-caption` text

---

### 💌 Quotes
**File:** `index.html`, Section `page5`
Edit the `<p>` inside each `.quote-card`
Change the personal note paragraph too

---

### 💍 Final Question
**File:** `index.html`, Section `page6`
Change the `h2` text to your question

---

### 💖 Final Message
**File:** `index.html`, Section `page7`
- Change "Always have. Always will." text
- Change the final quote paragraph
- Change the signature line

---

### 📅 Days Counter
**File:** `script.js`
Find: `const START_DATE = new Date(2024, 0, 1);`
Change to your actual start date.
Month is 0-indexed: Jan=0, Feb=1, Mar=2 ... Dec=11

Example: June 15, 2023 → `new Date(2023, 5, 15)`

---

### 🎵 Music
1. Download a romantic instrumental (MP3)
2. Rename file to `music.mp3`
3. Put it inside the `/images/` folder

Good sources: YouTube → MP3 converter (for personal use only)

---

### 🎨 Colors
**File:** `style.css`, top `:root` section
```css
--pink: #ff6b8a;        ← Main pink
--pink-light: #ffb6c1;  ← Light pink
--purple: #c084fc;      ← Purple accent
```

---

## 🚀 How to Open Locally

Just double-click `index.html` in your file manager.
OR drag it into any browser window.

---

## 🌐 How to Host Free (Send Her a Link)

### Option 1 — GitHub Pages (Recommended)
1. Create a free GitHub account
2. New repository → upload all files
3. Settings → Pages → select main branch
4. Your link: `https://yourusername.github.io/romantic-site`

### Option 2 — Netlify (Drag & Drop)
1. Go to netlify.com → sign up free
2. Drag your entire folder onto their site
3. Get a link instantly!

### Option 3 — Vercel
Similar to Netlify, very easy.

---

## 💡 Extra Tips

- Music autoplay is blocked by browsers until user clicks something — the music starts on first button click automatically
- Make sure all photo files are lowercase (photo1.jpg not Photo1.JPG)
- Test on mobile — it's fully responsive!
- Works best in Chrome, Firefox, Safari

---

Made with 💖 for you
